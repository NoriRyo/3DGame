using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BallShot : MonoBehaviour
{
    [SerializeField] GameObject sphere;
    [SerializeField] GameObject childObj;
    [SerializeField] float speed = 300;  // �e�̑���
    [SerializeField] private GameObject chargeEffect;    //
    public static int remaining = 1000; //�c�@
    public static bool charge = false; //
    [SerializeField] Text stocktext;

    public Slider emainingMeter; //�c�@���[�^�[
    int count;
    private Animator animator;  // �A�j���[�^�[�R���|�[�l���g�擾�p

    void Start()
    {
        childObj = transform.GetChild(0).gameObject;
        // �A�j���[�^�[�R���|�[�l���g�擾
        animator = GetComponent<Animator>();
        emainingMeter.value = 1;
    }

    void Update()
    {
        stocktext.text = "�c : " + remaining;
        //stocktext.text = "�c : ��";
        //chargeEffect.SetActive(false);
        //Debug.Log(remaining);
        if (emainingMeter.value <= 1)
        {
                emainingMeter.value = emainingMeter.value + 0.001f;
            if (PlayerMove.death == false && charge == true || PlayerMove.death == false && Input.GetKey(KeyCode.Z))
            {
                chargeEffect.SetActive(true);
            }
            else
            {
                chargeEffect.SetActive(false);
            }

            //�e���`���[�W
            if (emainingMeter.value == 1)
            {
                remaining = 3;
            }
            else if (emainingMeter.value >= 0.6)
            {
                remaining = 2;
            }
            else if (emainingMeter.value >= 0.3)
            {
                remaining = 1;
            }
            else
            {
                remaining = 0;
            }
        }
        if (remaining == 0)
        {
            Button.ButtonShot = false;
        }

        //if (animator.GetCurrentAnimatorStateInfo(0).IsName("isMoving"))

        if (Button.ButtonShot == true)
        {
            PlayerMove.stop = true;�@// �v���C���[�̈ړ����~�߂�
            animator.SetBool("Attack", true); // �A�j���[�V�����؂�ւ�
            count++;
            //�V���b�g��������ď������Ĕ��˂���
            if(count >=  80)
            {
                emainingMeter.value = emainingMeter.value - 0.34f;
                GameObject ball = (GameObject)Instantiate(sphere, childObj.transform.position, Quaternion.identity);
                Rigidbody ballRigidbody = ball.GetComponent<Rigidbody>();
                ballRigidbody.AddForce(transform.forward * speed);
                count = 0;
                Button.ButtonShot = false;
            }
        }
        else
        {
               Button.ButtonShot = false;
                animator.SetBool("Attack", false); // �A�j���[�V�����؂�ւ�
        }
    }

    
}