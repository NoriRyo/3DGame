using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Button : MonoBehaviour
{

    public static bool ButtonShot;

    int count;
    // Start is called before the first frame update
    void Start()
    {
        ButtonShot = false;
    }

    // Update is called once per frame
    void Update()
    {
        // �X�y�[�X
        //if(Input.GetKeyDown("space") || Input.GetMouseButton(0))
        if (Input.GetMouseButton(0))
        {
            count++;
            //Debug.Log(count);

        }
        else
        {
            if(count < 50 && count > 1)
            {
                if (ButtonShot == false && PlayerMove.stop == false && PlayerMove.death == false && BallShot.remaining >= 1)
                {
                    BallShot.remaining = BallShot.remaining - 1;
                    ButtonShot = true;
                }
            }
            count = 0;
            //Debug.Log("�����Ă���");
        }
        

    }

    public void Shot()�@//�V���b�g�{�^��
    {
        if (ButtonShot == false && PlayerMove.stop == false && PlayerMove.death == false && BallShot.remaining >= 1)
        {
            BallShot.remaining = BallShot.remaining - 1;
            ButtonShot = true;
        }
    }

    public void OnButtonDown()
    {
        if(PlayerMove.death == false)
        {
            Debug.Log("down");
            BallShot.charge = true;
        }
        
    }
    // �{�^���𗣂����Ƃ��̏���
    public void OnButtonUp()
    {
        if (PlayerMove.death == false)
        {
            Debug.Log("up");
            BallShot.charge = false;
        }
            
    }
}
