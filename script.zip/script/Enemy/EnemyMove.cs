using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMove : MonoBehaviour
{
    private float MoveSpeed = 2.0f;
    void FixedUpdate()
    {
        Vector3 posi = this.transform.localPosition;

        posi.x = Mathf.Sin(Time.time) * MoveSpeed;
        posi.z = Mathf.Cos(Time.time) * MoveSpeed;
        this.transform.localPosition = new Vector3(posi.x, posi.y, posi.z);
    }
}
