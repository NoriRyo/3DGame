using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyWarp : MonoBehaviour
{
    // ワープ間隔
    [SerializeField] float interval = 800;
    private float time;
    private float vecX;
    private float vecZ;
    // Start is called before the first frame update
    void Start()
    {
        interval += 101;
    }

    // Update is called once per frame
    void Update()
    {
        time++;

        if (time >= interval)
        {
            //指定の範囲内をランダムで移動する
            vecX = Random.Range(-10f, 10f);
            vecZ = Random.Range(-8f, 5f);
            this.transform.position = new Vector3(vecX, 0.5f, vecZ);
            time = 1.0f;
        }
    }
}
