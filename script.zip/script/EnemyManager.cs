using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyManager : MonoBehaviour
{
    private GameObject[] enemyBox;
    [SerializeField] Text enemyText;

    void Update()
    {
        enemyBox = GameObject.FindGameObjectsWithTag("Enemy");
        enemyText.text = "�c�� : "  + enemyBox.Length + " ��";
        //print("�G�̐��F" + enemyBox.Length);
    }
}
