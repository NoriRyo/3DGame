using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PBallCon : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField] private GameObject explosion; //����
    [SerializeField] private GameObject trajectory;//�O��
    SphereCollider sphereCol;
    Rigidbody rb;
    int count;
    void Start()
    {
        //explosion.SetActive(false);
        sphereCol = GetComponent<SphereCollider>();
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        count++;
        if(count > 1000)
        {
            //�e���폜
            Destroy(gameObject);
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        // �e���Z�Z�ɓ���������`
        if (collision.gameObject.tag == "wall"||
            collision.gameObject.tag == "Enemy" || collision.gameObject.tag == "Ball" )
        {
            explosion.SetActive(true);
            trajectory.SetActive(false);

            // Rigidbody �� Collider �� �����ɂ���
            rb.isKinematic = true;
            sphereCol.enabled = false;
        }
    }
}
