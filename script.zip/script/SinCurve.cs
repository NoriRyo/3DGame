using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SinCurve : MonoBehaviour
{
    private float MoveSpeed = 5.0f;
    // Start is called before the first frame update
    void Start()
    {

    }
 
    // Update is called once per frame
    void Update()
    {
        //Vector3 pos = this.transform.localPosition;
        ////�����f�[�^���擾
        //float t = pos.x;
        ////Y���W�ʒu��Sin(t)����Z�o
        //pos.x = Mathf.Sin(t * 5) * 3 + 0.25f;
        ////X���W�ʒu����������������
        ////pos.x += -0.1f;
        ////���W�ʒu�X�V
        //this.transform.localPosition = pos;

        //posi.x = Mathf.Sin(Time.time);
        //this.transform.localPosition = new Vector3(Mathf.Sin(Time.time) * MoveSpeed, posi.y, posi.z);

        Vector3 pos = this.transform.position;
        pos.x = Mathf.Sin(Time.time) * MoveSpeed;
        this.transform.position = pos;

    }
}
