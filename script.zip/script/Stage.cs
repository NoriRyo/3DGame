using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stage : MonoBehaviour
{
    bool a;
    int b;
    void Start()
    {
        a = false;
        b = 0;
    }
    void Update()
    {
        //GameObject Child = gameObject.transform.GetChild(0).gameObject;
        //Debug.Log(Child);
        if (Input.GetKeyDown("z"))
        {
            Debug.Log("->");
            a = true;
            
        }

        if(a)
        {
            gameObject.transform.GetChild(b).gameObject.SetActive(false);
            b = b + 1;
            gameObject.transform.GetChild(b).gameObject.SetActive(true);
            a = false;
        }


    }
}
