using UnityEngine;
using System.Collections;
using System.Collections.Generic;
public class Test : MonoBehaviour
{

    private Vector3 m_Direction;
    [SerializeField] VariableJoystick m_VariableJoystick;�@// �X�e�B�b�N
    

    void Start()
    {
        m_VariableJoystick.SetMode(JoystickType.Floating);
        
    }

    //private void FixedUpdate()
    //{
    //   // if (Input.GetKey(KeyCode.Space))
    //    {
    //        RaycastHit hit;
    //        //�ȉ��P�s�ǉ����܂���
    //        Debug.DrawRay(gameObject.transform.position, Vector3.up * 6, Color.blue, 0.1f);
    //        if (Physics.Raycast(gameObject.transform.position, Vector3.up, out hit, 6.0f))
    //        {
    //            Destroy(hit.collider.gameObject);
    //        }
    //    }
    //}
    private void Update()
    {
        m_Direction = Vector3.forward * m_VariableJoystick.Vertical + Vector3.right * m_VariableJoystick.Horizontal;
        //if (Input.GetKey(KeyCode.Space))
        {
            RaycastHit hit;
            Debug.DrawRay(gameObject.transform.position, m_Direction * 60, Color.blue, 0.1f);
            if (Physics.SphereCast(gameObject.transform.position, 1.0f, m_Direction, out hit, 50.0f))
            {
                //if (hit.collider.gameObject.tag == "Enemy")
                //{
                //    hit.collider.gameObject.GetComponent<EnemyColor>();
                //    hit.collider.gameObject.GetComponent<MeshRenderer>().material.color = new Color(EnemyColor.x, EnemyColor.x, EnemyColor.x, EnemyColor.x);
                //}

            }
        }
    }

}