using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class TitleButton : MonoBehaviour
{
    //public Image button;
    bool FadeCountStart;
    int FadeCount = 0;

    public void StartOnClick()
    {
        //GetComponent<AudioSource>().Play();
        FadeCountStart = true;
        //Debug.Log("�����ꂽ!");  // ���O���o��
        Fadeout.fadeout = true;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Fadeout.fadeend == true)
        {
            Debug.Log("Scene���ڍs���܂�");
            SceneManager.LoadScene("home");
        }
    }
}
