using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class goal : MonoBehaviour
{
    [SerializeField] private GameObject portal;    //�|�[�^��
    GameObject[] tagObjects;
    int count;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Check("Enemy");
        if(count >= 400)
        {
            portal.SetActive(true);
        }
    }

    void Check(string tagname)
    {
        tagObjects = GameObject.FindGameObjectsWithTag(tagname);
        //Debug.Log(tagObjects.Length);
        if (tagObjects.Length == 0)
        {
            count++;
        }
    }
}
